# Table of contents

* [README](README.md)

## 序

* [序](xu/xu.md)

## 立志篇

* [你想要做什么](li-zhi-pian/ni-xiang-yao-zuo-shi-mo.md)

## 自救篇

* [ICS课程经验分享](zi-jiu-pian/ics-ke-cheng-jing-yan-fen-xiang/README.md)
  * [西浦Y2课程](zi-jiu-pian/ics-ke-cheng-jing-yan-fen-xiang/xi-pu-y2-ke-cheng.md)
  * [西浦Y3课程](zi-jiu-pian/ics-ke-cheng-jing-yan-fen-xiang/xi-pu-y3-ke-cheng.md)
  * [利物浦CS大三课程介绍](zi-jiu-pian/ics-ke-cheng-jing-yan-fen-xiang/li-wu-pu-cs-da-san-ke-cheng-jie-shao.md)
  * [西浦Y4选课指南](zi-jiu-pian/ics-ke-cheng-jing-yan-fen-xiang/xi-pu-y4-xuan-ke-zhi-nan.md)
* [实习经验指北](zi-jiu-pian/shi-xi-jing-yan-zhi-bei.md)
  * [Backend](zi-jiu-pian/shi-xi-jing-yan-zhi-bei/backend.md)
* [做有价值的研究](zi-jiu-pian/zuo-you-jia-zhi-de-yan-jiu/README.md)
  * [如何衡量学术价值](zi-jiu-pian/zuo-you-jia-zhi-de-yan-jiu/ru-he-heng-liang-xue-shu-jia-zhi.md)
  * [获得科研机会的途径](zi-jiu-pian/zuo-you-jia-zhi-de-yan-jiu/huo-de-ke-yan-ji-hui-de-tu-jing.md)
* [投身开源社区](zi-jiu-pian/tou-shen-kai-yuan-she-qu.md)

## 访谈集

* [19级同学申请总结 (CS/DS/ECE)](fang-tan-ji/19-ji-tong-xue-shen-qing-zong-jie-csdsece/README.md)
  * [美研23fall申请 (Yingxi Chen)](fang-tan-ji/19-ji-tong-xue-shen-qing-zong-jie-csdsece/mei-yan-23fall-shen-qing-yingxi-chen.md)
  * [美研23fall申请 (Pin Qian)](fang-tan-ji/19-ji-tong-xue-shen-qing-zong-jie-csdsece/mei-yan-23fall-shen-qing-pin-qian.md)
  * [美研23fall申请 (Hejie Huang)](fang-tan-ji/19-ji-tong-xue-shen-qing-zong-jie-csdsece/mei-yan-23fall-shen-qing-hejie-huang.md)
