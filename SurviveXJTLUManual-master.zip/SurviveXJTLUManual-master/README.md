# README

## GitHub repo地址

{% embed url="https://github.com/Survive-XJTLU-CS/SurviveXJTLUManual" %}

## 提issue

如果大家对本手册中某些内容有疑问，欢迎在GitHub repo下提issue



## 如何提PR

在gitbook.com网站上利用github账号登录，fork [Survive-XJTLU-CS](https://github.com/Survive-XJTLU-CS)/[**SurviveXJTLUManual**](https://github.com/Survive-XJTLU-CS/SurviveXJTLUManual) 到个人账户，导入repo并在markdown文件中做修改，commit到自己repo再提起PR，通过review后合并到master branch



## 目录

参见[summary.md](https://github.com/Survive-XJTLU-CS/SurviveXJTLUManual/blob/master/SUMMARY.md)

